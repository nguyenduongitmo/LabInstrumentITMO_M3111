#!/usr/bin/env python
# coding=utf-8

print """
Greetings!

It looks like you are trying to install this package (called `package`). STOP!

`package` is a set of tools to make Python packages easier to write and
maintain, and to make the resulting packages easier for their users to
install.

If you are not a (possibly aspiring) Python package author, you can stop
reading right now.

...

I'm glad you are still reading. You must be a (possibly aspiring) Python
package author. Good on you!

To use this stuff either untar package-#.#.#.tar.gz (get it from
http://pypi.python.org/pypi/package/) or get/git the development sources
directly from http://github.com/ingydotnet/package-py. Put the `package`
directory under your src directory, next to the Python packages you are
authoring, and call it `package-py/`.

Further instructions can be found at http://pypi.python.org/pypi/package/

Enjoy!

"""

