%(name)s - Package description goes here
--------------------------------------

Installation
------------

Use::

    > sudo pip install %(name)s

or::

    > sudo easy install %(name)s

or::

    > git clone git://github.com/%(github_id)s/%(name)s-py.git
    > cd %(name)s-py
    > sudo make install

Usage
-----

Development Status
------------------

Community
---------

Authors
-------

* %(author)s <%(author_email)s>

Copyright
---------

%(name)s is Copyright (c) %(current_year)s, %(author)s

%(name)s is licensed under the New BSD License. See the LICENSE file.
