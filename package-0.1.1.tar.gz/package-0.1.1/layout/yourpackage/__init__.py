"""\
This is your package, '%(name)s'.

It was provided by the package, `package`.

Please change this documentation, and write this module!
"""

__version__ = '0.0.1'

# If you run 'make test', this is your failing test.
# raise Exception("\n\n\tNow it's time to write your '%(name)s' module!!!\n\n")
